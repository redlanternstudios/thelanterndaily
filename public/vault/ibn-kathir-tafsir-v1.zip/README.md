# Ibn Kathir Tafsir — Complete Machine-Readable Edition
The Lantern Daily Sovereign Scripture Collection (v1.0.0)

## Overview
This archive contains the authoritative English commentary of Hafiz Ibn Kathir, structured for machine consumption, LLM RAG indexing, and scholarly reference.

## Contents
1. `metadata.json` — Surah index, thematic tags, and classification mapping.
2. `quran_thematic_index.json` — 6,236 ayat mapped to economic and governance themes.
3. `LICENSE.txt` — Public Domain / Open Access.

Stamped for verified subscribers of The Lantern Daily (thelanterndaily.com).
